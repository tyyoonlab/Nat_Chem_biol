close all;
clear all;
%% Notation
% A: mch-2A-GFP
% gbw : mch-2A-GFP-GLUT3(TM 1-2, WT)
% gdw : mch-2A-GFP-GLUT3(TM 1-4, WT)
% gfw : mch-2A-GFP-GLUT3(TM 1-6, WT)
% ggw : mch-2A-GFP-GLUT3(full length, WT)
% h_(something) : histogram
% ratio_(something) : GFP/mch ratio

%% Setting mch-2A-control %%
A = readmatrix('A.csv');
% remove negative-value columns
A(A(:,6)<0,:)=[];
A(A(:,6)==0,:)=[];
A(A(:,7)<0,:)=[];
A(A(:,7)==0,:)=[];
%reduce counts to 20000
A = A(1:20000, :);
ratio_A = A(:,6)./A(:,7);
hA = histogram(ratio_A,'Normalization','count');
hA.BinWidth = 0.02;
hA_X = hA.BinEdges(1:end-1)+hA.BinWidth./2;
hA_Y = hA.Values;
plot(hA_X, hA_Y);
% Setting Normalization value for setting GFP/mch = 1 in mch-2A-GFP
[~,ind] = max(hA_Y);
norm_val = hA_X(ind);
close(1);
%% Plot
%% 1. A
N = numel(A(:,6));
GFP = A(:,6);
mch = A(:,7);
figure(1);
scatter(mch,GFP/norm_val,1, '.','k');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
% plot(1:1:1e6, 1:1:1e6, 'b');
hold off;

%% 2. gi
gi= readmatrix('gi.csv');
% remove negative-value columns
gi(gi(:,6)<0,:)=[];
gi(gi(:,6)==0,:)=[];
gi(gi(:,7)<0,:)=[];
gi(gi(:,7)==0,:)=[];
gi = gi(1:20000, :);
ratio_gi = gi(:,6)./gi(:,7);
N = numel(gi(:,6));
GFP = gi(:,6);
mch = gi(:,7);
figure(2);
scatter(mch,GFP/norm_val,1, '.','k');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-SQS1(Full length)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
hold off;

%% 3. mi
mi= readmatrix('mi.csv');
% remove negative-value columns
mi(mi(:,6)<0,:)=[];
mi(mi(:,6)==0,:)=[];
mi(mi(:,7)<0,:)=[];
mi(mi(:,7)==0,:)=[];
mi = mi(1:20000, :);
ratio_mi = mi(:,6)./mi(:,7);
N = numel(mi(:,6));
GFP = mi(:,6);
mch = mi(:,7);
figure(3);
scatter(GFP/norm_val,mch,1, '.','k');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('GFP(normalized)', 'FontSize', 16);
ylabel('mCherry', 'FontSize', 16);
title('TRAM2-mCherry-2A-GFP', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
hold off;
