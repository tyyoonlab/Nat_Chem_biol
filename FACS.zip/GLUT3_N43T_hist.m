close all;
clear all;
%% Notation
% A: mch-2A-GFP
% gbw : mch-2A-GFP-GLUT3(TM 1-2, WT)
% gdw : mch-2A-GFP-GLUT3(TM 1-4, WT)
% gfw : mch-2A-GFP-GLUT3(TM 1-6, WT)
% ggw : mch-2A-GFP-GLUT3(full length, WT)
% h_(something) : histogram
% ratio_(something) : GFP/mch ratio

%% Setting mch-2A-control %%
A = readmatrix('A.csv');
% remove negative-value columns
A(A(:,6)<0,:)=[];
A(A(:,6)==0,:)=[];
A(A(:,7)<0,:)=[];
A(A(:,7)==0,:)=[];
%reduce counts to 20000
A = A(1:20000, :);
ratio_A = A(:,6)./A(:,7);
hA = histogram(ratio_A,'Normalization','count');
hA.BinWidth = 0.02;
hA_X = hA.BinEdges(1:end-1)+hA.BinWidth./2;
hA_Y = hA.Values;
plot(hA_X, hA_Y);
% Setting Normalization value for setting GFP/mch = 1 in mch-2A-GFP
[~,ind] = max(hA_Y);
norm_val = hA_X(ind);
close(1);
%% Experimental groups
%% 1. gg
gg= readmatrix('gg.csv');
% remove negative-value columns
gg(gg(:,6)<0,:)=[];
gg(gg(:,6)==0,:)=[];
gg(gg(:,7)<0,:)=[];
gg(gg(:,7)==0,:)=[];
gg = gg(1:20000, :);
ratio_gg = gg(:,6)./gg(:,7);
figure(11);
hgg = histogram(ratio_gg,'Normalization','count');
hgg.BinWidth = 0.02;
hgg_X = hgg.BinEdges(1:end-1)+hgg.BinWidth./2;
hgg_Y = hgg.Values;
close(11);
% Setting Normalization value for setting GFP/mch = 1 in
% mch-2A-GFP-GLUT3(WT)
[~,ind1] = max(hgg_Y);
norm_GLUT3WT = hgg_X(ind1);

%% 2. gf
gf= readmatrix('gf.csv');
% remove negative-value columns
gf(gf(:,6)<0,:)=[];
gf(gf(:,6)==0,:)=[];
gf(gf(:,7)<0,:)=[];
gf(gf(:,7)==0,:)=[];
gf = gf(1:20000, :);
ratio_gf = gf(:,6)./gf(:,7);
figure(11);
hgf = histogram(ratio_gf,'Normalization','count');
hgf.BinWidth = 0.02;
hgf_X = hgf.BinEdges(1:end-1)+hgf.BinWidth./2;
hgf_Y = hgf.Values;
close(11);
%% 3. ge
ge= readmatrix('ge.csv');
% remove negative-value columns
ge(ge(:,6)<0,:)=[];
ge(ge(:,6)==0,:)=[];
ge(ge(:,7)<0,:)=[];
ge(ge(:,7)==0,:)=[];
ge = ge(1:20000, :);
ratio_ge = ge(:,6)./ge(:,7);
figure(11);
hge = histogram(ratio_ge,'Normalization','count');
hge.BinWidth = 0.02;
hge_X = hge.BinEdges(1:end-1)+hge.BinWidth./2;
hge_Y = hge.Values;
close(11);
%% 4. gd
gd= readmatrix('gd.csv');
% remove negative-value columns
gd(gd(:,6)<0,:)=[];
gd(gd(:,6)==0,:)=[];
gd(gd(:,7)<0,:)=[];
gd(gd(:,7)==0,:)=[];
gd = gd(1:20000, :);
ratio_gd = gd(:,6)./gd(:,7);
figure(11);
hgd = histogram(ratio_gd,'Normalization','count');
hgd.BinWidth = 0.02;
hgd_X = hgd.BinEdges(1:end-1)+hgd.BinWidth./2;
hgd_Y = hgd.Values;
close(11);
%% 5. gc
gc= readmatrix('gc.csv');
% remove negative-value columns
gc(gc(:,6)<0,:)=[];
gc(gc(:,6)==0,:)=[];
gc(gc(:,7)<0,:)=[];
gc(gc(:,7)==0,:)=[];
gc = gc(1:20000, :);
ratio_gc = gc(:,6)./gc(:,7);
figure(11);
hgc = histogram(ratio_gc,'Normalization','count');
hgc.BinWidth = 0.02;
hgc_X = hgc.BinEdges(1:end-1)+hgc.BinWidth./2;
hgc_Y = hgc.Values;
close(11);
%% 6. gb
gb= readmatrix('gb.csv');
% remove negative-value columns
gb(gb(:,6)<0,:)=[];
gb(gb(:,6)==0,:)=[];
gb(gb(:,7)<0,:)=[];
gb(gb(:,7)==0,:)=[];
gb = gb(1:20000, :);
ratio_gb = gb(:,6)./gb(:,7);
figure(11);
hgb = histogram(ratio_gb,'Normalization','count');
hgb.BinWidth = 0.02;
hgb_X = hgb.BinEdges(1:end-1)+hgb.BinWidth./2;
hgb_Y = hgb.Values;
close(11);
%% 7. ga
ga= readmatrix('ga.csv');
% remove negative-value columns
ga(ga(:,6)<0,:)=[];
ga(ga(:,6)==0,:)=[];
ga(ga(:,7)<0,:)=[];
ga(ga(:,7)==0,:)=[];
ga = ga(1:20000, :);
ratio_ga = ga(:,6)./ga(:,7);
figure(11);
hga = histogram(ratio_ga,'Normalization','count');
hga.BinWidth = 0.02;
hga_X = hga.BinEdges(1:end-1)+hga.BinWidth./2;
hga_Y = hga.Values;
close(11);
%% 7. gh
gh= readmatrix('gh.csv');
% remove negative-value columns
gh(gh(:,6)<0,:)=[];
gh(gh(:,6)==0,:)=[];
gh(gh(:,7)<0,:)=[];
gh(gh(:,7)==0,:)=[];
gh = gh(1:20000, :);
ratio_gh = gh(:,6)./gh(:,7);
figure(11);
hgh = histogram(ratio_gh,'Normalization','count');
hgh.BinWidth = 0.02;
hgh_X = hgh.BinEdges(1:end-1)+hgh.BinWidth./2;
hgh_Y = hgh.Values;
close(11);
%% merged
figure(1000);
hold on;
plot(hgg_X/norm_val, hgg_Y, 'Color','black', 'LineWidth', 2.0); % full-length
plot(hgf_X/norm_val, hgf_Y, 'Color','blue', 'LineWidth', 2.0); % N domain
plot(hge_X/norm_val, hge_Y, 'Color',[0.4660, 0.6740, 0.1880], 'LineWidth', 2.0); % TMD 1-5
plot(hgd_X/norm_val, hgd_Y, 'Color',[0.75, 0, 0.75], 'LineWidth', 2.0); % TMD 1-4
plot(hgc_X/norm_val, hgc_Y, 'Color','red', 'LineWidth', 2.0); % TMD 1-3
plot(hgb_X/norm_val, hgb_Y, 'Color',[0.3010, 0.7450, 0.9330], 'LineWidth', 2.0); % TMD 1-2
plot(hga_X/norm_val, hga_Y, 'Color','cyan', 'LineWidth', 2.0); % TMD 1-2
plot(hgh_X/norm_val, hgh_Y, 'Color',[0.9290, 0.6940, 0.1250], 'LineWidth', 2.0); % TMD 1-2
ax = gca;
ax.FontSize = 14; 
xlim([0 1]);
xlabel('GFP:mCherry (normalized to mCherry-2A-GFP)', 'FontSize', 16);
ylabel('Cell Count', 'FontSize', 16);
set(gca,'yticklabel',[])
title('GLUT3(N43T) constructs', 'FontSize', 20);
xline(norm_GLUT3WT/norm_val, '--', 'LineWidth', 2);
s = .7;
text(s, 7000, 'Full length','Color','black','FontSize',14);
text(s, 6500, 'N-domain','Color','blue','FontSize',14);
text(s, 6000, '(TMD 1-6)','Color','blue','FontSize',14);
text(s, 5500, 'TMD 1-5','Color',[0.4660, 0.6740, 0.1880],'FontSize',14);
text(s, 5000, 'TMD 1-4','Color',[0.75, 0, 0.75],'FontSize',14);
text(s, 4500, 'TMD 1-3','Color','red','FontSize',14);
text(s, 4000, 'TMD 1-2','Color',[0.3010, 0.7450, 0.9330],'FontSize',14);
text(s, 3500, 'TMD 1','Color','cyan','FontSize',14);
text(s, 3000, 'C-domain','Color',[0.9290, 0.6940, 0.1250],'FontSize',14);
text(s, 2500, '(TMD 7-12)','Color',[0.9290, 0.6940, 0.1250],'FontSize',14);
hold off;
%% merged-mch2AGFPGLUT3
figure(2000);
hold on;
plot(hgg_X/norm_GLUT3WT, hgg_Y, 'Color','black', 'LineWidth', 2.0); % full-length
plot(hgf_X/norm_GLUT3WT, hgf_Y, 'Color','blue', 'LineWidth', 2.0); % N domain
plot(hge_X/norm_GLUT3WT, hge_Y, 'Color',[0.4660, 0.6740, 0.1880], 'LineWidth', 2.0); % TMD 1-5
plot(hgd_X/norm_GLUT3WT, hgd_Y, 'Color',[0.75, 0, 0.75], 'LineWidth', 2.0); % TMD 1-4
plot(hgc_X/norm_GLUT3WT, hgc_Y, 'Color','red', 'LineWidth', 2.0); % TMD 1-3
plot(hgb_X/norm_GLUT3WT, hgb_Y, 'Color',[0.3010, 0.7450, 0.9330], 'LineWidth', 2.0); % TMD 1-2
plot(hga_X/norm_GLUT3WT, hga_Y, 'Color',[0.3010, 0.7450, 0.9330], 'LineWidth', 2.0); % TMD 1-2
plot(hgh_X/norm_GLUT3WT, hgh_Y, 'Color',[0.9290, 0.6940, 0.1250], 'LineWidth', 2.0); % TMD 1-2
ax = gca;
ax.FontSize = 14; 
xlim([0 2]);
xlabel('GFP:mCherry (normalized to mCherry-2A-GFP-GLUT3)', 'FontSize', 16);
ylabel('Cell Count', 'FontSize', 16);
set(gca,'yticklabel',[])
title('GLUT3(N43T) constructs', 'FontSize', 20);
xline(1, '--', 'LineWidth', 2);
scale = 1.4;
text(scale, 7000, 'Full length','Color','black','FontSize',14);
text(scale, 6400, 'N-domain','Color','blue','FontSize',14);
text(scale, 5800, '(TMD 1-6)','Color','blue','FontSize',14);
text(scale, 5200, 'TMD 1-5','Color',[0.4660, 0.6740, 0.1880],'FontSize',14);
text(scale, 4600, 'TMD 1-4','Color',[0.75, 0, 0.75],'FontSize',14);
text(scale, 4000, 'TMD 1-3','Color','red','FontSize',14);
text(scale, 3400, 'TMD 1-2','Color',[0.3010, 0.7450, 0.9330],'FontSize',14);
text(scale, 2800, 'TMD 1','Color','cyan','FontSize',14);
text(scale, 2200, 'C-domain','Color',[0.9290, 0.6940, 0.1250],'FontSize',14);
text(scale, 1600, '(TMD 7-12)','Color',[0.9290, 0.6940, 0.1250],'FontSize',14);
hold off;