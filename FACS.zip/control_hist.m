close all;
clear all;
%% Notation
% A: mch-2A-GFP
% gbw : mch-2A-GFP-GLUT3(TM 1-2, WT)
% gdw : mch-2A-GFP-GLUT3(TM 1-4, WT)
% gfw : mch-2A-GFP-GLUT3(TM 1-6, WT)
% ggw : mch-2A-GFP-GLUT3(full length, WT)
% h_(something) : histogram
% ratio_(something) : GFP/mch ratio

%% Setting mch-2A-control %%
A = readmatrix('A.csv');
% remove negative-value columns
A(A(:,6)<0,:)=[];
A(A(:,6)==0,:)=[];
A(A(:,7)<0,:)=[];
A(A(:,7)==0,:)=[];
A = A(1:20000, :);
ratio_A = A(:,6)./A(:,7);
figure(1);
hA = histogram(ratio_A,'Normalization','count');
hA.BinWidth = 0.02;
hA_X = hA.BinEdges(1:end-1)+hA.BinWidth./2;
hA_Y = hA.Values;
close(1);
% Setting Normalization value for setting GFP/mch = 1 in mch-2A-GFP
[~,indA] = max(hA_Y);
max_A = hA_X(indA);
norm_val = hA_X(indA);
figure(1);
hold on;
plot(hA_X/norm_val, hA_Y, 'LineWidth', 2.0);
ax = gca;
ax.FontSize = 14; 
xlim([0 3]);
xlabel('GFP:mCherry(normalized)', 'FontSize', 16);
ylabel('Cell Count', 'FontSize', 16);
set(gca,'yticklabel',[])
title('mCherry-2A-GFP', 'FontSize', 20);
hold off;
%% Experimental groups
%% 1. gi
gi= readmatrix('gi.csv');
% remove negative-value columns
gi(gi(:,6)<0,:)=[];
gi(gi(:,6)==0,:)=[];
gi(gi(:,7)<0,:)=[];
gi(gi(:,7)==0,:)=[];
gi = gi(1:20000, :);
ratio_gi = gi(:,6)./gi(:,7);
figure(11);
hgi = histogram(ratio_gi,'Normalization','count');
hgi.BinWidth = 0.02;
hgi_X = hgi.BinEdges(1:end-1)+hgi.BinWidth./2;
hgi_Y = hgi.Values;
close(11);
figure(12);
plot(hgi_X/norm_val, hgi_Y, 'LineWidth', 2.0);
ax = gca;
ax.FontSize = 14; 
xlim([0 1]);
xlabel('GFP:mCherry(normalized)', 'FontSize', 16);
ylabel('Cell Count', 'FontSize', 16);
set(gca,'yticklabel',[])
title('mCherry-2A-GFP-SQS1(Full length)', 'FontSize', 20);
%% 2. mi
mi= readmatrix('mi.csv');
% remove negative-value columns
mi(mi(:,6)<0,:)=[];
mi(mi(:,6)==0,:)=[];
mi(mi(:,7)<0,:)=[];
mi(mi(:,7)==0,:)=[];
mi = mi(1:20000, :);
ratio_mi = mi(:,7)./mi(:,6);
figure(21);
hmi = histogram(ratio_mi,'Normalization','count');
hmi.BinWidth = 0.02;
hmi_X = hmi.BinEdges(1:end-1)+hmi.BinWidth./2;
hmi_Y = hmi.Values;
close(21);
figure(22);
plot(hmi_X*norm_val, hmi_Y, 'LineWidth', 2.0);
ax = gca;
ax.FontSize = 14; 
xlim([0 3]);
xlabel('mCherry:GFP(normalized)', 'FontSize', 16);
ylabel('Cell Count', 'FontSize', 16);
set(gca,'yticklabel',[])
title('TRAM2-mCherry-2A-GFP', 'FontSize', 20);
