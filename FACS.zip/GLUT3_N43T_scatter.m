close all;
clear all;
%% Notation
% A: mch-2A-GFP
% gbw : mch-2A-GFP-GLUT3(TM 1-2, WT)
% gdw : mch-2A-GFP-GLUT3(TM 1-4, WT)
% gfw : mch-2A-GFP-GLUT3(TM 1-6, WT)
% ggw : mch-2A-GFP-GLUT3(full length, WT)
% h_(something) : histogram
% ratio_(something) : GFP/mch ratio

%% Setting mch-2A-control %%
A = readmatrix('A.csv');
% remove negative-value columns
A(A(:,6)<0,:)=[];
A(A(:,6)==0,:)=[];
A(A(:,7)<0,:)=[];
A(A(:,7)==0,:)=[];
%reduce counts to 20000
A = A(1:20000, :);
ratio_A = A(:,6)./A(:,7);
hA = histogram(ratio_A,'Normalization','count');
hA.BinWidth = 0.02;
hA_X = hA.BinEdges(1:end-1)+hA.BinWidth./2;
hA_Y = hA.Values;
plot(hA_X, hA_Y);
% Setting Normalization value for setting GFP/mch = 1 in mch-2A-GFP
[~,ind] = max(hA_Y);
norm_val = hA_X(ind);
close(1);
%% Experimental groups
%% 1. gg
gg= readmatrix('gg.csv');
% remove negative-value columns
gg(gg(:,6)<0,:)=[];
gg(gg(:,6)==0,:)=[];
gg(gg(:,7)<0,:)=[];
gg(gg(:,7)==0,:)=[];
gg = gg(1:20000, :);
ratio_gg = gg(:,6)./gg(:,7);
figure(11);
hgg = histogram(ratio_gg,'Normalization','count');
hgg.BinWidth = 0.02;
hgg_X = hgg.BinEdges(1:end-1)+hgg.BinWidth./2;
hgg_Y = hgg.Values;
close(11);
% Setting Normalization value for setting GFP/mch = 1 in
% mch-2A-GFP-GLUT3(N43T)
[~,ind1] = max(hgg_Y);
norm_GLUT3N43T = hgg_X(ind1);
N = numel(gg(:,6));
GFP = gg(:,6);
mch = gg(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(10);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(Full length, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;

%% 2. gf
gf= readmatrix('gf.csv');
% remove negative-value columns
gf(gf(:,6)<0,:)=[];
gf(gf(:,6)==0,:)=[];
gf(gf(:,7)<0,:)=[];
gf(gf(:,7)==0,:)=[];
gf = gf(1:20000, :);
ratio_gf = gf(:,6)./gf(:,7);
N = numel(gf(:,6));
GFP = gf(:,6);
mch = gf(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(20);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(N domain, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;
%% 3. ge
ge= readmatrix('ge.csv');
% remove negative-value columns
ge(ge(:,6)<0,:)=[];
ge(ge(:,6)==0,:)=[];
ge(ge(:,7)<0,:)=[];
ge(ge(:,7)==0,:)=[];
ge = ge(1:20000, :);
ratio_ge = ge(:,6)./ge(:,7);
N = numel(ge(:,6));
GFP = ge(:,6);
mch = ge(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(30);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(TMD 1-5, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;
%% 4. gd
gd= readmatrix('gd.csv');
% remove negative-value columns
gd(gd(:,6)<0,:)=[];
gd(gd(:,6)==0,:)=[];
gd(gd(:,7)<0,:)=[];
gd(gd(:,7)==0,:)=[];
gd = gd(1:20000, :);
ratio_gd = gd(:,6)./gd(:,7);
N = numel(gd(:,6));
GFP = gd(:,6);
mch = gd(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(40);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(TMD 1-4, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;
%% 5. gc
gc= readmatrix('gc.csv');
% remove negative-value columns
gc(gc(:,6)<0,:)=[];
gc(gc(:,6)==0,:)=[];
gc(gc(:,7)<0,:)=[];
gc(gc(:,7)==0,:)=[];
gc = gc(1:20000, :);
ratio_gc = gc(:,6)./gc(:,7);
N = numel(gc(:,6));
GFP = gc(:,6);
mch = gc(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(50);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(TMD 1-3, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;
%% 6. gb
gb= readmatrix('gb.csv');
% remove negative-value columns
gb(gb(:,6)<0,:)=[];
gb(gb(:,6)==0,:)=[];
gb(gb(:,7)<0,:)=[];
gb(gb(:,7)==0,:)=[];
gb = gb(1:20000, :);
ratio_gb = gb(:,6)./gb(:,7);
N = numel(gb(:,6));
GFP = gb(:,6);
mch = gb(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(60);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(TMD 1-2, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;
%% 7. ga
ga= readmatrix('ga.csv');
% remove negative-value columns
ga(ga(:,6)<0,:)=[];
ga(ga(:,6)==0,:)=[];
ga(ga(:,7)<0,:)=[];
ga(ga(:,7)==0,:)=[];
ga = ga(1:20000, :);
ratio_ga = ga(:,6)./ga(:,7);
N = numel(ga(:,6));
GFP = ga(:,6);
mch = ga(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(70);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(TMD 1, N43T)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;
%% 7. gh
gh= readmatrix('gh.csv');
% remove negative-value columns
gh(gh(:,6)<0,:)=[];
gh(gh(:,6)==0,:)=[];
gh(gh(:,7)<0,:)=[];
gh(gh(:,7)==0,:)=[];
gh = gh(1:20000, :);
ratio_gh = gh(:,6)./gh(:,7);
N = numel(gh(:,6));
GFP = gh(:,6);
mch = gh(:,7);
GU = [];
GD = [];
MU = [];
MD = [];
figure(80);
for i = 1:N
    G = GFP(i); m = mch(i);
    val = G/m;
    val = val/norm_GLUT3N43T;
    if val>1
        GU(end+1) = G/norm_val;
        MU(end+1) = m;
    else
        GD(end+1) = G/norm_val;
        MD(end+1) = m;
    end
end
hold on;
scatter(MD,GD,1, '.','k');
scatter(MU,GU,1, '.','r');
set(gca,'xscale','log');
set(gca,'yscale','log');
xticks([ 1e1 1e2 1e3 1e4 1e5]);
yticks([ 1e1 1e2 1e3 1e4 1e5]);
xlim([1 1e6]); ylim([1 1e6]);
xlabel('mCherry', 'FontSize', 16);
ylabel('GFP(normalized)', 'FontSize', 16);
title('mCherry-2A-GFP-GLUT3(C domain)', 'FontSize', 20);
ax = gca;
ax.FontSize = 14;
Reds = numel(MU)/N;
Redstr = string(round(Reds*100, 2));
text(1e2, 1e4, strcat(Redstr, '%'),'Color','red','FontSize',14);
hold off;